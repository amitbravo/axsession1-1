import React from 'react'
import Navbar from './components/NavBar'
import MainPage from './components/MainPage'
//function or a class
// function -> functional component
// class -> a class component

export default function App () {
  return (
    <div style={{ backgroundColor: 'white' }}>
      <div><Navbar /></div>
      <div><MainPage /></div>
    </div>
  )
}
