import React from 'react'

//function or a class
// function -> functional component
// class -> a class component

export default function App () {
  return (
    <div style={{ marginTop: 20, paddingLeft: 20,  display: 'flex', flexDirection: 'row', height: 100,  alignItems: 'center'  }}>

        <div style={{ display: 'flex', flexDirection: 'row', backgroundColor: '#5c86ac', width: 200, height: 130, justifyContent: 'center', alignItems: 'center' }}>
            <div style={{ color: 'white', fontSize: 18, fontWeight: 'bold' }}>Lionsgate</div>
        </div>

        <div style={{ marginLeft: 10, display: 'flex', flexDirection: 'row', backgroundColor: '#5c86ac', width: 200, height: 130, justifyContent: 'center', alignItems: 'center' }}>
            <div style={{ color: 'white', fontSize: 18, fontWeight: 'bold' }}>HBO</div>
        </div>

        <div style={{ marginLeft: 10, display: 'flex', flexDirection: 'row', backgroundColor: '#5c86ac', width: 200, height: 130, justifyContent: 'center', alignItems: 'center' }}>
            <div style={{ color: 'white', fontSize: 18, fontWeight: 'bold' }}>Discovery+</div>
        </div>

    </div>
  )
}
