import React from 'react'

//function or a class
// function -> functional component
// class -> a class component

export default function App () {
  return (
    <div style={{ display: 'flex', flexDirection: 'row', height: 100, backgroundColor: '#444444', alignItems: 'center'  }}>

        <div style={{ paddingLeft: 20, color: '#fafafa', fontSize: 28 }}>VideoApp</div>

        <div style={{ marginLeft: 50, color: 'white', display: 'flex', flexDirection: 'row' }}>
              <div style={{ marginLeft: 20, padding: 4 }}>Home</div>
              <div style={{ marginLeft: 20, padding: 4 }}>Detail</div>
              <div style={{ marginLeft: 20, padding: 4 }}>Profile</div>
        </div>

    </div>
  )
}
